const MY_API_KEY = 'c0af6827cemsh249ad0ac2f4087fp19ea60jsnbc5e03ecd889';
export { MY_API_KEY };